package com.glow.flashlight;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int CAMERA_PERMISSION_REQUEST = 31;
    private static final int BG = Color.rgb(10, 12, 20);
    private static final int AMBER = Color.rgb(255, 170, 45);

    private CameraManager cameraManager;
    private String cameraId;
    private boolean torchOn;
    private boolean screenMode;
    private boolean screenOn;
    private int level = 75;
    private TextView status;
    private TextView powerButton;
    private TextView percent;
    private SeekBar slider;
    private FrameLayout root;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable levelUpdate = this::applyTorchLevel;
    private float previousWindowBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        previousWindowBrightness = getWindow().getAttributes().screenBrightness;
        buildInterface();
        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            cameraManager.registerTorchCallback(torchCallback, handler);
        }
    }

    private void buildInterface() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL);
        column.setPadding(dp(26), dp(36), dp(26), dp(22));
        root.addView(column, new FrameLayout.LayoutParams(-1, -1));

        TextView brand = text("G L O W", 12, Color.GRAY, Typeface.BOLD);
        column.addView(brand, new LinearLayout.LayoutParams(-2, dp(22)));
        TextView title = text("Flashlight", 31, Color.WHITE, Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-2, dp(48));
        titleParams.bottomMargin = dp(24);
        column.addView(title, titleParams);

        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        modes.setPadding(dp(5), dp(5), dp(5), dp(5));
        modes.setBackground(round(Color.rgb(35, 38, 48), dp(16)));
        Button ledMode = modeButton("Phone LED", true);
        Button screenModeButton = modeButton("Screen", false);
        modes.addView(ledMode, new LinearLayout.LayoutParams(0, dp(44), 1));
        modes.addView(screenModeButton, new LinearLayout.LayoutParams(0, dp(44), 1));
        column.addView(modes, new LinearLayout.LayoutParams(-1, dp(54)));
        ledMode.setOnClickListener(v -> setMode(false, ledMode, screenModeButton));
        screenModeButton.setOnClickListener(v -> setMode(true, ledMode, screenModeButton));

        View spacer = new View(this);
        column.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));

        powerButton = text("ϟ", 70, Color.WHITE, Typeface.NORMAL);
        powerButton.setGravity(Gravity.CENTER);
        powerButton.setBackground(round(Color.rgb(36, 39, 48), dp(100)));
        powerButton.setElevation(dp(8));
        LinearLayout.LayoutParams powerParams = new LinearLayout.LayoutParams(dp(174), dp(174));
        column.addView(powerButton, powerParams);
        powerButton.setOnClickListener(v -> toggleLight());

        status = text("Ready to light up", 14, Color.LTGRAY, Typeface.NORMAL);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, dp(52));
        statusParams.topMargin = dp(8);
        column.addView(status, statusParams);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(15), dp(18), dp(12));
        panel.setBackground(round(Color.rgb(30, 33, 43), dp(20)));
        LinearLayout.LayoutParams panelParams = new LinearLayout.LayoutParams(-1, dp(104));
        panelParams.topMargin = dp(15);
        column.addView(panel, panelParams);

        LinearLayout labels = new LinearLayout(this);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = text("BRIGHTNESS", 12, Color.LTGRAY, Typeface.BOLD);
        labels.addView(label, new LinearLayout.LayoutParams(0, dp(22), 1));
        percent = text("75%", 13, Color.WHITE, Typeface.BOLD);
        labels.addView(percent, new LinearLayout.LayoutParams(-2, dp(22)));
        panel.addView(labels);

        slider = new SeekBar(this);
        slider.setMax(100);
        slider.setProgress(level);
        slider.setProgressTintList(android.content.res.ColorStateList.valueOf(AMBER));
        slider.setThumbTintList(android.content.res.ColorStateList.valueOf(AMBER));
        panel.addView(slider, new LinearLayout.LayoutParams(-1, dp(46)));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                level = Math.max(progress, 1);
                percent.setText(level + "%");
                if (fromUser && !screenMode && torchOn) {
                    handler.removeCallbacks(levelUpdate);
                    handler.postDelayed(levelUpdate, 35);
                } else if (fromUser && screenMode && screenOn) {
                    applyScreenLight();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        View lowerSpacer = new View(this);
        column.addView(lowerSpacer, new LinearLayout.LayoutParams(1, 0, 1));
        TextView footer = text("Controls this phone’s rear LED", 12, Color.GRAY, Typeface.NORMAL);
        footer.setGravity(Gravity.CENTER);
        column.addView(footer, new LinearLayout.LayoutParams(-1, dp(28)));
        updateAppearance();
    }

    private Button modeButton(String label, boolean selected) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTextColor(selected ? Color.WHITE : Color.LTGRAY);
        button.setBackground(round(selected ? Color.rgb(75, 78, 88) : Color.TRANSPARENT, dp(13)));
        return button;
    }

    private void setMode(boolean useScreen, Button led, Button screen) {
        if (screenMode == useScreen) return;
        if (torchOn) turnTorchOff();
        if (screenMode && screenOn) {
            screenOn = false;
            restoreScreenBrightness();
        }
        screenMode = useScreen;
        led.setTextColor(useScreen ? Color.LTGRAY : Color.WHITE);
        led.setBackground(round(useScreen ? Color.TRANSPARENT : Color.rgb(75, 78, 88), dp(13)));
        screen.setTextColor(useScreen ? Color.WHITE : Color.LTGRAY);
        screen.setBackground(round(useScreen ? Color.rgb(75, 78, 88) : Color.TRANSPARENT, dp(13)));
        status.setText(useScreen ? "Screen light is off" : "Rear LED is off");
        updateAppearance();
    }

    private void toggleLight() {
        if (screenMode) {
            screenOn = !screenOn;
            if (screenOn) applyScreenLight(); else restoreScreenBrightness();
            status.setText(screenOn ? "Screen light is on" : "Screen light is off");
            updateAppearance();
        } else if (torchOn) {
            turnTorchOff();
        } else {
            turnTorchOn();
        }
    }

    private void turnTorchOn() {
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            status.setText("This device has no camera flash");
            return;
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
            return;
        }
        try {
            cameraId = findFlashCamera();
            if (cameraId == null) throw new IllegalStateException("No rear camera flash is available");
            applyTorchLevel();
        } catch (Exception e) {
            status.setText("Could not turn on the rear LED");
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private String findFlashCamera() throws CameraAccessException {
        for (String id : cameraManager.getCameraIdList()) {
            CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
            Boolean flash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
            if (Boolean.TRUE.equals(flash) && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) return id;
        }
        return null;
    }

    private void applyTorchLevel() {
        if (cameraId == null || checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                CameraCharacteristics c = cameraManager.getCameraCharacteristics(cameraId);
                Integer max = c.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL);
                int strength = Math.max(1, Math.round((max == null ? 1 : max) * level / 100f));
                cameraManager.turnOnTorchWithStrengthLevel(cameraId, strength);
            } else {
                cameraManager.setTorchMode(cameraId, true);
            }
            torchOn = true;
            status.setText(Build.VERSION.SDK_INT >= 33 ? "Rear LED is on" : "Rear LED on · brightness fixed by Android version");
            updateAppearance();
        } catch (CameraAccessException | SecurityException e) {
            torchOn = false;
            status.setText("Could not control the rear LED");
        }
    }

    private void turnTorchOff() {
        handler.removeCallbacks(levelUpdate);
        if (cameraId != null) {
            try { cameraManager.setTorchMode(cameraId, false); }
            catch (CameraAccessException | SecurityException ignored) { }
        }
        torchOn = false;
        status.setText("Rear LED is off");
        updateAppearance();
    }

    private void applyScreenLight() {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.screenBrightness = Math.max(0.05f, level / 100f);
        getWindow().setAttributes(params);
        updateAppearance();
    }

    private void restoreScreenBrightness() {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.screenBrightness = previousWindowBrightness;
        getWindow().setAttributes(params);
    }

    private void updateAppearance() {
        boolean on = screenMode ? screenOn : torchOn;
        root.setBackgroundColor(screenMode && screenOn ? Color.rgb(255, 250, 228) : BG);
        powerButton.setText(on ? "ϟ" : "ϟ");
        powerButton.setTextColor(on ? Color.WHITE : Color.LTGRAY);
        powerButton.setBackground(round(on ? AMBER : Color.rgb(36, 39, 48), dp(100)));
        status.setTextColor(screenMode && screenOn ? Color.DKGRAY : Color.LTGRAY);
        slider.setEnabled(screenMode ? screenOn : torchOn);
    }

    private TextView text(String value, int size, int color, int style) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, style);
        return view;
    }

    private android.graphics.drawable.GradientDrawable round(int color, int radius) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) turnTorchOn();
            else status.setText("Camera access is required to control the rear LED");
        }
    }

    @Override
    protected void onPause() {
        if (torchOn) turnTorchOff();
        if (screenOn) {
            screenOn = false;
            restoreScreenBrightness();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (cameraManager != null) cameraManager.unregisterTorchCallback(torchCallback);
        restoreScreenBrightness();
        super.onDestroy();
    }

    private final CameraManager.TorchCallback torchCallback = new CameraManager.TorchCallback() {
        @Override public void onTorchModeUnavailable(String id) {
            if (id.equals(cameraId)) runOnUiThread(() -> {
                torchOn = false;
                status.setText("Rear LED is unavailable");
                updateAppearance();
            });
        }
    };
}
