# Glow for Android

Native Android flashlight app with a rear LED mode and a full-screen mode. On Android 13+ devices that expose torch strength control, the brightness slider changes the physical flash strength. Older Android versions expose only on/off control, so LED brightness is fixed there. The screen mode adjusts this app window's brightness and restores the prior setting when the app leaves the foreground.

## Build an APK in the cloud from Windows

The repository includes `.github/workflows/android.yml`, which builds an installable debug APK and saves it as a GitHub Actions artifact. Put this project in a GitHub repository, then run **Actions → Build Android APK → Run workflow**. Download `glow-android-apk` from the completed workflow run and install `app-debug.apk` on the phone. Android may prompt you to allow installation from the browser or file manager.

The APK is debug-signed for direct personal testing. A Play Store release needs a release signing key and a Play App Signing setup.

## Build locally

Open this folder in Android Studio; Gradle will fetch the Android Gradle Plugin and SDK platform as needed. Then use **Build → Build APK(s)**, or run `gradle assembleDebug` after installing Gradle and Android SDK Platform 35.
