import AVFoundation
import Foundation

@MainActor
final class TorchController: ObservableObject {
    @Published private(set) var isOn = false
    @Published private(set) var isStarting = false
    @Published private(set) var status = "Ready to light up"
    @Published var level = 0.75 {
        didSet { applyLevel() }
    }

    private let captureQueue = DispatchQueue(label: "com.glow.flashlight.capture")
    private var captureSession: AVCaptureSession?
    private var captureDevice: AVCaptureDevice?
    private var operationID = 0

    func toggle() {
        isOn ? turnOff() : turnOn()
    }

    func turnOn() {
        guard !isOn, !isStarting else { return }
        isStarting = true
        status = "Requesting camera access…"
        operationID += 1
        let request = operationID

        Task {
            let allowed = await withCheckedContinuation { continuation in
                AVCaptureDevice.requestAccess(for: .video) { granted in
                    continuation.resume(returning: granted)
                }
            }

            guard request == operationID else { return }
            guard allowed else {
                isStarting = false
                status = "Camera access is needed to control the LED. Enable it in Settings."
                return
            }

            status = "Turning on rear LED…"
            let requestedLevel = level
            captureQueue.async { [weak self] in
                guard let self else { return }
                do {
                    try self.startTorch(level: requestedLevel)
                    Task { @MainActor in
                        guard request == self.operationID else { return }
                        self.isStarting = false
                        self.isOn = true
                        self.status = "Rear LED is on"
                    }
                } catch {
                    Task { @MainActor in
                        guard request == self.operationID else { return }
                        self.isStarting = false
                        self.isOn = false
                        self.status = error.localizedDescription
                    }
                }
            }
        }
    }

    func turnOff() {
        operationID += 1
        isStarting = false
        isOn = false
        status = "Rear LED is off"

        captureQueue.async { [weak self] in
            guard let self else { return }
            if let device = self.captureDevice, device.hasTorch {
                do {
                    try device.lockForConfiguration()
                    device.torchMode = .off
                    device.unlockForConfiguration()
                } catch {
                    // Still stop the session so the hardware is released.
                }
            }
            self.captureSession?.stopRunning()
            self.captureSession = nil
            self.captureDevice = nil
        }
    }

    private func applyLevel() {
        guard isOn else { return }
        let requestedLevel = level
        captureQueue.async { [weak self] in
            guard let self, let device = self.captureDevice, device.hasTorch else { return }
            do {
                try device.lockForConfiguration()
                do {
                    let maxLevel = AVCaptureDevice.maxAvailableTorchLevel
                    try device.setTorchModeOn(level: min(max(Float(requestedLevel), 0.01), maxLevel))
                    device.unlockForConfiguration()
                } catch {
                    device.unlockForConfiguration()
                    throw error
                }
            } catch {
                Task { @MainActor in self.status = "Could not change LED brightness: \(error.localizedDescription)" }
            }
        }
    }

    private func startTorch(level: Double) throws {
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            throw TorchError.unavailable("No rear camera is available on this iPhone.")
        }
        guard device.hasTorch, device.isTorchAvailable else {
            throw TorchError.unavailable("This iPhone does not expose a controllable camera LED.")
        }

        let session = AVCaptureSession()
        session.beginConfiguration()
        session.sessionPreset = .photo
        do {
            let input = try AVCaptureDeviceInput(device: device)
            guard session.canAddInput(input) else {
                session.commitConfiguration()
                throw TorchError.unavailable("The camera could not be started.")
            }
            session.addInput(input)
            session.commitConfiguration()
            session.startRunning()

            try device.lockForConfiguration()
            do {
                let maxLevel = AVCaptureDevice.maxAvailableTorchLevel
                try device.setTorchModeOn(level: min(max(Float(level), 0.01), maxLevel))
                device.unlockForConfiguration()
            } catch {
                device.unlockForConfiguration()
                throw error
            }

            self.captureDevice = device
            self.captureSession = session
        } catch {
            if session.isRunning { session.stopRunning() }
            throw error
        }
    }
}

private enum TorchError: LocalizedError {
    case unavailable(String)

    var errorDescription: String? {
        switch self {
        case .unavailable(let message): message
        }
    }
}
