import SwiftUI

@main
struct GlowNativeApp: App {
    var body: some Scene {
        WindowGroup {
            FlashlightView()
                .preferredColorScheme(.dark)
        }
    }
}
