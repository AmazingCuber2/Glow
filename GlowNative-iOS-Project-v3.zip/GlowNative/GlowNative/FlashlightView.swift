import SwiftUI

private enum LightMode: String, CaseIterable, Identifiable {
    case led = "Phone LED"
    case screen = "Screen"
    var id: String { rawValue }
}

struct FlashlightView: View {
    @StateObject private var torch = TorchController()
    @Environment(\.scenePhase) private var scenePhase
    @State private var mode: LightMode = .led
    @State private var screenLevel = 0.8

    private var isLightOn: Bool { mode == .led ? torch.isOn : screenLevel > 0 }

    var body: some View {
        ZStack {
            (mode == .screen && screenLevel > 0
             ? Color(red: screenLevel, green: screenLevel, blue: screenLevel * 0.94)
             : Color(red: 0.035, green: 0.045, blue: 0.07))
                .ignoresSafeArea()
                .animation(.easeInOut(duration: 0.2), value: screenLevel)

            VStack(spacing: 24) {
                header
                modePicker
                Spacer(minLength: 10)
                powerButton
                Text(mode == .led ? torch.status : (isLightOn ? "Screen light is on" : "Screen light is off"))
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(mode == .screen && screenLevel > 0 ? .black.opacity(0.55) : .white.opacity(0.62))
                    .multilineTextAlignment(.center)
                    .frame(minHeight: 38)
                brightnessControl
                Spacer(minLength: 10)
                footer
            }
            .padding(.horizontal, 24)
            .padding(.top, 12)
            .padding(.bottom, 16)
        }
        .preferredColorScheme(.dark)
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { torch.turnOff() }
        }
        .onChange(of: mode) { _, newMode in
            if newMode == .screen {
                torch.turnOff()
            } else {
                screenLevel = 0
            }
        }
    }

    private var header: some View {
        VStack(spacing: 5) {
            Text("GLOW")
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .tracking(4)
                .foregroundStyle(mode == .screen && screenLevel > 0 ? .black.opacity(0.48) : .white.opacity(0.5))
            Text("Flashlight")
                .font(.system(size: 32, weight: .semibold, design: .rounded))
                .foregroundStyle(mode == .screen && screenLevel > 0 ? .black : .white)
        }
        .frame(maxWidth: .infinity)
    }

    private var modePicker: some View {
        Picker("Light source", selection: $mode) {
            ForEach(LightMode.allCases) { mode in
                Text(mode.rawValue).tag(mode)
            }
        }
        .pickerStyle(.segmented)
        .padding(5)
        .glassPanel(cornerRadius: 18)
        .tint(.orange)
    }

    private var powerButton: some View {
        Button {
            if mode == .led {
                torch.toggle()
            } else {
                screenLevel = screenLevel > 0 ? 0 : 0.8
            }
        } label: {
            ZStack {
                Circle()
                    .fill(isLightOn ? Color.orange : Color.white.opacity(0.08))
                    .frame(width: 178, height: 178)
                    .overlay(Circle().strokeBorder(.white.opacity(isLightOn ? 0.35 : 0.12), lineWidth: 1))
                    .shadow(color: isLightOn ? .orange.opacity(0.38) : .clear, radius: 42)
                Image(systemName: isLightOn ? "flashlight.on.fill" : "flashlight.off.fill")
                    .font(.system(size: 58, weight: .medium))
                    .foregroundStyle(isLightOn ? .white : .white.opacity(0.7))
            }
            .frame(maxWidth: .infinity)
            .contentShape(Circle())
        }
        .buttonStyle(.plain)
        .disabled(mode == .led && torch.isStarting)
        .accessibilityLabel(isLightOn ? "Turn flashlight off" : "Turn flashlight on")
    }

    private var brightnessControl: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("BRIGHTNESS")
                    .font(.caption.weight(.bold))
                    .tracking(1.4)
                Spacer()
                Text("\(Int((mode == .led ? torch.level : screenLevel) * 100))%")
                    .font(.system(.caption, design: .monospaced).weight(.semibold))
            }
            .foregroundStyle(mode == .screen && screenLevel > 0 ? .black.opacity(0.65) : .white.opacity(0.7))

            HStack(spacing: 14) {
                Image(systemName: "sun.min")
                Slider(value: mode == .led ? $torch.level : $screenLevel, in: 0.05...1)
                    .tint(.orange)
                    .disabled(mode == .led && !torch.isOn)
                Image(systemName: "sun.max.fill")
            }
            .foregroundStyle(mode == .screen && screenLevel > 0 ? .black.opacity(0.7) : .white.opacity(0.72))
        }
        .padding(18)
        .glassPanel(cornerRadius: 22)
    }

    private var footer: some View {
        HStack(spacing: 7) {
            Image(systemName: mode == .led ? "camera.macro" : "iphone")
            Text(mode == .led ? "Controls the iPhone’s rear LED" : "Uses the display as a light")
        }
        .font(.caption)
        .foregroundStyle(mode == .screen && screenLevel > 0 ? .black.opacity(0.45) : .white.opacity(0.42))
        .padding(.bottom, 8)
    }
}

private extension View {
    @ViewBuilder
    func glassPanel(cornerRadius: CGFloat) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        } else {
            self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous).strokeBorder(.white.opacity(0.1)))
        }
    }
}

#Preview {
    FlashlightView()
}
