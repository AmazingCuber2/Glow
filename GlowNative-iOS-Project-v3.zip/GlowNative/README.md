# Glow for iOS

Glow is a native SwiftUI flashlight for iPhone. Phone LED mode controls the real rear camera LED, including its hardware brightness level. Screen mode provides a dimmable full-screen light. The interface uses iOS 26 Liquid Glass where available and a material fallback on iOS 17–25.

## Build on a Mac

1. Open `GlowNative.xcodeproj` in Xcode 26 or newer.
2. Select the **Glow** target, then **Signing & Capabilities**. Choose your Apple development team and replace `com.example.glow` with a bundle identifier you own if needed.
3. Connect your iPhone, select it as the run destination, and press **Run**. Accept the camera access prompt; Glow uses the camera hardware to control the LED and does not record video.
4. To make an IPA, select **Any iOS Device (arm64)** and choose **Product → Archive**. In Organizer, select the archive, choose **Distribute App**, then export using Development or Ad Hoc signing for the devices you intend to install on.

The exported app must be signed with a provisioning profile. An IPA cannot be installed by simply copying it to an iPhone unless it is signed for that installation method.

## Notes

- Minimum deployment target: iOS 17.
- Liquid Glass is enabled conditionally for iOS 26 and newer.
- iOS requires camera permission to control the torch through AVFoundation. Glow does not capture or save camera images or video.
- The flashlight is switched off when the app goes into the background.
